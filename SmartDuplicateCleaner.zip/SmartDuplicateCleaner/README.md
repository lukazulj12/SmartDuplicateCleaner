# Smart Duplicate Cleaner

Android aplikacija za pronalaženje, usporedbu i sigurno uklanjanje dupliciranih datoteka.
Radi lokalno na uređaju – bez registracije, bez oglasa, bez slanja fotografija na internet.

> **Važno o izgradnji:** projekt je napisan u okruženju u kojem su Googleovi Maven poslužitelji i Android SDK
> bili blokirani mrežnom politikom, pa **APK nije izgrađen niti je Android modul kompajliran**. Modul `core`
> (sva logika prepoznavanja duplikata, pravila odabira i sigurnosti brisanja) stvarno je kompajliran i
> testiran – 40 testova prolazi (vidi `TEST_RESULTS.md`). Android modul (`app`) pažljivo je pregledan, ali
> moguće je da pri prvoj izgradnji Android Studio prijavi pokoju sitnu pogrešku kompajliranja; u tom slučaju
> pošaljite poruku pogreške i ispravit ću je.

---

## 1. Otvaranje projekta u Android Studiju

1. Instalirajte **Android Studio Ladybug (2024.2) ili noviji** – https://developer.android.com/studio
2. Raspakirajte `SmartDuplicateCleaner.zip`.
3. U Android Studiju: **File → Open…** i odaberite mapu `SmartDuplicateCleaner` (onu u kojoj je `settings.gradle.kts`).
4. Kliknite **Trust Project**. Android Studio će preuzeti Gradle 8.11.1 i sve biblioteke (prvi put traje nekoliko minuta, potreban je internet).
5. Ako zatraži, instalirajte **Android SDK Platform 35** (Tools → SDK Manager).
6. Pričekajte da završi „Gradle sync” (donja traka).

## 2. Izgradnja APK-a

**Iz izbornika:** Build → Build App Bundle(s) / APK(s) → **Build APK(s)**.
Kad završi, kliknite „locate” u obavijesti. Datoteka je:

```
app/build/outputs/apk/debug/app-debug.apk
```

**Iz terminala** (u mapi projekta):

```bash
# Linux / macOS
./gradlew assembleDebug
# Windows
gradlew.bat assembleDebug
```

Optimizirana (manja) verzija: `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.
Release je radi jednostavnosti potpisan debug ključem (dovoljno za vlastiti mobitel; za Google Play treba vlastiti ključ).

**Testovi:**

```bash
./gradlew :core:test                      # logika duplikata, pravila, sigurnost brisanja (JVM)
./gradlew :app:testDebugUnitTest          # potpunost hrvatskog i engleskog prijevoda
./gradlew :app:connectedDebugAndroidTest  # promjena jezika (potreban spojen mobitel ili emulator)
```

## 3. Instalacija na mobitel

**Bez računala:** kopirajte `app-debug.apk` na mobitel (USB, Google Drive, e-pošta), otvorite ga u upravitelju
datoteka i dopustite „Instaliraj nepoznate aplikacije” za tu aplikaciju kada Android to zatraži. Dodirnite **Instaliraj**.

**Preko USB-a (ADB):** uključite „Otklanjanje pogrešaka putem USB-a” u opcijama za razvojne programere i pokrenite
`adb install -r app/build/outputs/apk/debug/app-debug.apk`.

Root pristup nije potreban. Potreban je **Android 11 ili noviji**.

## 4. Kako se koristi

1. **Glavni zaslon** → „Odobri pristup” (fotografije, video, audio). Po želji uključite „Pristup svim datotekama”
   (za dokumente i arhive na cijeloj pohrani) ili dodajte pojedine mape.
2. **Postavke** → najveća veličina datoteke, vrste datoteka, mape, pravila odabira datoteke koju zadržavate, način brisanja, jezik.
3. **Skeniraj datoteke** – napredak, broj pregledanih datoteka, pronađeni duplikati i procjena prostora prikazuju se uživo;
   skeniranje se može otkazati, a nastavlja se i kad izađete iz aplikacije (obavijest s gumbom „Odustani”).
4. **Pregled duplikata** – kartice: Sve, Potpuno identične, Isti naziv, Slične fotografije, Videozapisi, Audiozapisi, Dokumenti, Arhive i ostalo.
   U grupi: mrežni ili detaljan prikaz, status **ZADRŽATI** (zeleno, kvačica) ili **PREDLOŽENO / OZNAČENO ZA BRISANJE**
   (crveno, kanta), razlog odabira, „Zadrži ovu datoteku” jednim dodirom, usporedba preko cijelog zaslona s povećanjem
   i načinom „dvije odjednom”, prethodna/sljedeća grupa.
5. **Pregled prije brisanja** – konačan popis, broj datoteka i prostor koji će se osloboditi → **Potvrdi brisanje**.
   Za fotografije/video/audio Android dodatno prikazuje vlastiti dijalog potvrde.
6. **Izvještaj** – uspješno izbrisane datoteke, oslobođeni prostor i pogreške po datoteci.
7. **Oporavak** (ikona sata na glavnom zaslonu) – vraćanje ili trajno brisanje.

## 5. Kako aplikacija prepoznaje duplikate

| Razina | Metoda | Automatski prijedlog |
|---|---|---|
| **Potpuno identične** | SHA-256 cijelog sadržaja (najprije se uspoređuju veličina i prvih 64 KB, pa se cijela datoteka čita samo kad je potrebno) | Da |
| **Ista fotografija** (npr. WhatsApp kopija, smanjena, ponovno komprimirana, „(1)”, „copy”) | pHash (DCT 32×32, udaljenost ≤ 6/64) + potvrda dHashom + sličan omjer stranica; EXIF orijentacija se primjenjuje prije hashiranja | Da |
| **Slične fotografije** | pHash unutar praga iz postavki (70–98 %) | **Nikad** – samo ručno |
| **Isti naziv, različit sadržaj** | isti naziv, različit SHA-256 / veličina | **Nikad** – samo informativno |

Sigurnosna pravila ugrađena u jezgru (i pokrivena testovima):

- U **svakoj grupi uvijek ostaje barem jedna datoteka** – sučelje ne dopušta označiti posljednju, a plan brisanja se odbija ako bi se to ipak dogodilo.
- Ista datoteka pronađena kroz dva izvora (npr. MediaStore i odabrana mapa) prepoznaje se kao **ista fizička datoteka**, nikad kao vlastiti duplikat.
- Ako pravila ne daju **jednog** pobjednika ili nedostaju podaci, ništa se ne označava – traži se ručna odluka.
- Briše se **isključivo** zamrznuti, potvrđeni popis; datoteka koja se promijenila ili nestala nakon skeniranja preskače se.
- Datum kopiranja nikad se ne prikazuje kao datum snimanja; zamjenski datum je uvijek jasno označen.

## 6. Dopuštenja i zašto ih aplikacija traži

| Dopuštenje | Android | Svrha |
|---|---|---|
| `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO` | 13+ | Čitanje fotografija, videozapisa i audiozapisa radi usporedbe. |
| `READ_MEDIA_VISUAL_USER_SELECTED` | 14+ | Podrška za „Odabrane fotografije”; aplikacija tada upozorava da je pristup djelomičan. |
| `READ_EXTERNAL_STORAGE` | 11–12 | Isto kao gore na starijim verzijama. |
| `ACCESS_MEDIA_LOCATION` | 11+ | Čitanje izvornih (neredigiranih) bajtova fotografija – inače Android skriva GPS podatke pa bi SHA-256 usporedba bila manje precizna. Lokacija se ne koristi ni ne prikazuje. |
| `MANAGE_EXTERNAL_STORAGE` („Pristup svim datotekama”) | 11+ | **Neobavezno.** Samo za dokumente, arhive i ostale nemedijske datoteke izvan mapa koje ručno dodate. Uključuje se isključivo u sistemskim postavkama nakon objašnjenja. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC` | 11+ / 14+ | Skeniranje u pozadini s obaviješću o napretku. |
| `POST_NOTIFICATIONS` | 13+ | Prikaz obavijesti o napretku (neobavezno). |

Mape dodane preko sistemskog birača mapa (Storage Access Framework) ne trebaju posebno dopuštenje – Android daje pristup samo toj mapi.
Aplikacija **nema** dopuštenje za internet.

## 7. Arhitektura

```
core/ (čisti Kotlin, bez Androida – testira se na JVM-u)
  model/      ScannedFile, DuplicateGroup, KeepRules, ScanSettings
  hash/       Sha256 (streaming), PerceptualHash (pHash, dHash, EXIF orijentacija)
  logic/      DuplicateGrouper (+ BK-stablo), KeepSelector (pravila), SelectionState (zaštita grupa),
              DeletionPlanner, DeletionRunner, Dates/ExifDateParser, FileClassifier
  scan/       ScanEngine (nabrajanje → filtri → SHA-256 → pHash → grupiranje → EXIF → prijedlog)
  format/     Formatters (B/KB/MB/GB, DD.MM.GGGG)

app/ (Android)
  storage/    MediaStoreSource, SafTreeSource, FileSystemSource, AndroidContentAccess, StorageAccess
  scan/       ScanManager (korutine, otkazivanje), ScanService (usluga u prvom planu)
  deletion/   DeletionManager (MediaStore createDeleteRequest/createTrashRequest, SAF, oporavak)
  data/       Room (rezultati, oznake, predmemorija hashova, oporavak), DataStore (postavke)
  ui/         Jetpack Compose: početni zaslon, rezultati, grupa, usporedba, završni pregled, izvještaj,
              postavke, mape, oporavak; HR/EN lokalizacija (values/, values-hr/)
tools/        strings_source.py (izvor prijevoda), check_resources.py (provjera lokalizacije)
```

Tehnologije: Kotlin 2.0.21, Jetpack Compose (Material 3), Room 2.6.1, DataStore, Coroutines/Flow, Coil
(minijature umanjene na veličinu prikaza), AGP 8.7.3, Gradle 8.11.1, minSdk 30, targetSdk 35.

Potrošnja resursa: slike se za analizu dekodiraju umanjeno (najmanja stranica ~128–256 px), SHA-256 se računa
u blokovima od 64 KB, paralelizacija je ograničena na 2 posla, a hashovi nepromijenjenih datoteka čuvaju se u
predmemoriji pa je ponovno skeniranje brže. Nedostatak memorije pri jednoj slici ne ruši skeniranje.

## 8. Poznata ograničenja

1. **APK nije izgrađen u ovom okruženju** (vidi napomenu na vrhu). Logika jezgre je testirana; Android sloj nije kompajliran.
2. **Android 11+** (minSdk 30). Starije verzije nisu podržane jer nemaju sistemske dijaloge za sigurno brisanje medija.
3. **Bez „Pristupa svim datotekama”** aplikacija vidi samo fotografije, videozapise i audiozapise te datoteke u mapama koje ručno dodate.
   Sistemski birač mapa ne dopušta odabir korijena interne memorije, korijena mape Download ni mape Android/data.
4. **Android/data, Android/obb** i podaci drugih aplikacija nikad se ne skeniraju niti brišu. **Skrivene mape** (naziv počinje točkom) preskaču se pri skeniranju datotečnog sustava i dodanih mapa.
5. **Datum stvaranja datoteke** Android ne bilježi pouzdano, pa se ne koristi. Dostupni su datum snimanja (EXIF/metapodaci),
   datum dodavanja na uređaj (≈ datum kopiranja) i datum posljednje izmjene.
6. **Oporavak:** Androidov koš automatski briše medije nakon oko 30 dana; kopije iz dodanih mapa nalaze se u pohrani aplikacije i
   **gube se deinstalacijom**; datoteke izbrisane uz pristup svim datotekama premještaju se u mapu `SmartDuplicateCleaner_Oporavak`
   (s `.nomedia`) na istom volumenu i ostaju i nakon deinstalacije. Zapisi čije kopije više ne postoje automatski se uklanjaju.
7. **Slične fotografije** temelje se na perceptualnom hashu, ne na umjetnoj inteligenciji – izrezane, jako uređene ili zrcaljene verzije možda neće biti povezane.
   Videozapisi i audiozapisi uspoređuju se samo točno (SHA-256) i po nazivu.
8. **HEIC/HEIF i rijetki formati**: ako ih uređaj ne može dekodirati, za njih radi samo točna (SHA-256) usporedba; aplikacija to prijavljuje.
9. **Android 14+ „Odabrane fotografije”**: vide se samo odabrane fotografije; aplikacija prikazuje upozorenje.
10. **Android 15**: usluga u pozadini vrste dataSync ograničena je na 6 sati dnevno; nakon toga obavijest nestaje, a skeniranje se nastavlja dok je aplikacija aktivna.
11. **Google Play** ograničava dopuštenje „Pristup svim datotekama”; za instalaciju APK-a na vlastiti mobitel to nije prepreka.
12. Brisanje fotografija, videozapisa i audiozapisa uvijek prolazi kroz Androidov sistemski dijalog – to je zaštita sustava i ne može se zaobići.
