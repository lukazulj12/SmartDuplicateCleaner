# Room i Compose nose vlastita pravila; ovdje nema dodatnih.
-keepattributes *Annotation*
