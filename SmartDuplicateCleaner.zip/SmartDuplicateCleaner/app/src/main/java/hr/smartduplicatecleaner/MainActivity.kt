package hr.smartduplicatecleaner

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import hr.smartduplicatecleaner.ui.AppNavHost
import hr.smartduplicatecleaner.ui.theme.SdcTheme

/**
 * Jedina aktivnost. AppCompatActivity je potrebna kako bi promjena jezika
 * (AppCompatDelegate.setApplicationLocales) radila i na Androidu 11–12.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val container = (application as SdcApplication).container
        setContent {
            SdcTheme {
                AppNavHost(container)
            }
        }
    }
}
