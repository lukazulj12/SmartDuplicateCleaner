package hr.smartduplicatecleaner.data

import hr.smartduplicatecleaner.core.logic.GroupDecision
import hr.smartduplicatecleaner.core.logic.MemberDecision
import hr.smartduplicatecleaner.core.logic.Reason
import hr.smartduplicatecleaner.core.logic.SelectionState
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.CachedHashes
import hr.smartduplicatecleaner.core.scan.HashCache
import hr.smartduplicatecleaner.core.scan.ScanResult
import hr.smartduplicatecleaner.core.scan.SourceWarning
import hr.smartduplicatecleaner.core.scan.WarningKind
import hr.smartduplicatecleaner.data.db.AppDatabase
import hr.smartduplicatecleaner.data.db.FileEntity
import hr.smartduplicatecleaner.data.db.GroupEntity
import hr.smartduplicatecleaner.data.db.HashCacheEntity
import hr.smartduplicatecleaner.data.db.MarkEntity
import hr.smartduplicatecleaner.data.db.MemberEntity
import hr.smartduplicatecleaner.data.db.SummaryEntity
import kotlinx.coroutines.flow.Flow

/** Rezultati skeniranja učitani iz baze, spremni za pregled. */
data class ReviewData(
    val files: Map<String, ScannedFile>,
    val groups: List<DuplicateGroup>,
    val decisions: Map<String, GroupDecision>,
    val marked: Set<String>
)

class ResultsRepository(private val db: AppDatabase) {
    private val dao = db.results()

    val summary: Flow<SummaryEntity?> = dao.summaryFlow()
    val markCount: Flow<Int> = dao.markCountFlow()

    /**
     * Spremanje novog rezultata. Automatski prijedlozi (samo EXACT i VISUAL grupe s jasnim
     * pobjednikom) odmah se upisuju kao oznake – korisnik ih u pregledu može promijeniti.
     */
    suspend fun save(result: ScanResult, finishedAt: Long, maxFileSizeBytes: Long?) {
        val state = SelectionState(result.groups)
        state.applySuggestions(result.decisions.values, onlyConfirmed = false)
        val files = result.files.values.map { it.toEntity() }
        val groups = result.groups.mapIndexed { index, g ->
            val d = result.decisions[g.id]
            GroupEntity(g.id, g.type.name, g.category.name, g.maxDistance, d?.needsManual ?: true, Reason.encodeList(d?.notes.orEmpty()), index)
        }
        val members = result.groups.flatMap { g ->
            val d = result.decisions[g.id]
            g.members.map { m ->
                val md = d?.members?.firstOrNull { it.fileKey == m.fileKey }
                MemberEntity(g.id, m.fileKey, m.contentLabel, (md?.suggestion ?: Suggestion.UNDECIDED).name, Reason.encodeList(md?.reasons.orEmpty()))
            }
        }
        val s = result.stats
        val summary = SummaryEntity(
            finishedAt = finishedAt,
            filesListed = s.filesListed,
            filesAnalyzed = s.filesAnalyzed,
            analyzedBytes = s.analyzedBytes,
            skippedBySize = s.skippedBySize,
            skippedBySizeBytes = s.skippedBySizeBytes,
            skippedPotentialDuplicates = s.skippedPotentialDuplicates,
            skippedByCategory = s.skippedByCategory,
            skippedByFolder = s.skippedByFolder,
            unreadableFiles = s.unreadableFiles,
            undecodableImages = s.undecodableImages,
            duplicateFiles = s.duplicateFiles,
            reclaimableBytes = s.reclaimableBytes,
            groupCount = s.groupCount,
            warnings = encodeWarnings(result.warnings),
            maxFileSizeBytes = maxFileSizeBytes
        )
        dao.replaceAll(files, groups, members, state.marked.map { MarkEntity(it) }, summary)
    }

    suspend fun load(): ReviewData {
        val files = dao.files().associate { it.key to it.toModel() }
        val members = dao.members().groupBy { it.groupId }
        val groupEntities = dao.groups()
        val groups = groupEntities.mapNotNull { g ->
            val ms = members[g.id].orEmpty().filter { it.fileKey in files }
            if (ms.size < 2) null
            else DuplicateGroup(
                g.id,
                GroupType.valueOf(g.type),
                FileCategory.valueOf(g.category),
                ms.map { GroupMember(it.fileKey, it.contentLabel) },
                g.maxDistance
            )
        }
        val decisions = groupEntities.associate { g ->
            g.id to GroupDecision(
                g.id,
                members[g.id].orEmpty().map { m ->
                    MemberDecision(m.fileKey, enumValueOrNull<Suggestion>(m.suggestion) ?: Suggestion.UNDECIDED, Reason.decodeList(m.reasons))
                },
                g.needsManual,
                Reason.decodeList(g.notes)
            )
        }
        return ReviewData(files, groups, decisions, dao.marks().toSet())
    }

    suspend fun saveMarks(keys: Collection<String>) = dao.replaceMarks(keys)

    suspend fun summaryNow(): SummaryEntity? = dao.summary()

    /**
     * Uklanja izbrisane datoteke iz rezultata. Grupe s manje od dvije preostale datoteke se brišu,
     * a sažetak (oslobodivi prostor) se ponovno izračunava iz preostalih oznaka.
     */
    suspend fun removeFiles(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val list = keys.toList()
        list.chunked(500).forEach {
            dao.deleteMarks(it); dao.deleteMembers(it); dao.deleteFiles(it)
        }
        val members = dao.members().groupBy { it.groupId }
        val emptyGroups = dao.groups().filter { (members[it.id]?.size ?: 0) < 2 }.map { it.id }
        if (emptyGroups.isNotEmpty()) {
            dao.deleteMembersOfGroups(emptyGroups)
            dao.deleteGroups(emptyGroups)
        }
        refreshSummary()
    }

    /** Ponovni izračun broja duplikata i oslobodivog prostora prema trenutačnim oznakama. */
    suspend fun refreshSummary() {
        val s = dao.summary() ?: return
        val data = load()
        val partition = data.groups.filter { it.allowsAutoSuggestion }.flatMap { it.fileKeys }.toSet()
        val reclaim = data.marked.sumOf { data.files[it]?.sizeBytes ?: 0L }
        dao.insertSummary(s.copy(duplicateFiles = partition.size, reclaimableBytes = reclaim, groupCount = data.groups.size))
    }

    private fun encodeWarnings(list: List<SourceWarning>): String =
        list.joinToString("\n") { "${it.sourceId.replace('|', '/')}|${it.kind.name}|${it.detail.orEmpty().replace('\n', ' ').replace('|', '/')}" }

    companion object {
        fun decodeWarnings(text: String): List<SourceWarning> =
            text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
                val parts = line.split('|')
                if (parts.size < 2) null
                else SourceWarning(parts[0], enumValueOrNull<WarningKind>(parts[1]) ?: WarningKind.ERROR, parts.getOrNull(2)?.ifBlank { null })
            }
    }
}

inline fun <reified E : Enum<E>> enumValueOrNull(name: String?): E? =
    enumValues<E>().firstOrNull { it.name == name }

fun ScannedFile.toEntity() = FileEntity(
    key, uri, source.name, name, volume, relativeDir, sizeBytes, mimeType, category.name,
    dateTakenMillis, dateTakenSource?.name, dateAddedMillis, dateModifiedMillis, width, height,
    treeUri, documentId, absolutePath, sha256, pHash, dHash
)

fun FileEntity.toModel() = ScannedFile(
    key = key, uri = uri, source = enumValueOrNull<SourceType>(source) ?: SourceType.MEDIA_STORE,
    name = name, volume = volume, relativeDir = relativeDir, sizeBytes = sizeBytes, mimeType = mimeType,
    category = enumValueOrNull<FileCategory>(category) ?: FileCategory.OTHER,
    dateTakenMillis = dateTaken, dateTakenSource = enumValueOrNull<DateSource>(dateTakenSource),
    dateAddedMillis = dateAdded, dateModifiedMillis = dateModified, width = width, height = height,
    treeUri = treeUri, documentId = documentId, absolutePath = absolutePath,
    sha256 = sha256, pHash = pHash, dHash = dHash
)

/** Predmemorija hashova u Room bazi (poziva se iz pozadinskih dretvi skeniranja). */
class RoomHashCache(db: AppDatabase) : HashCache {
    private val dao = db.hashCache()

    override fun lookup(file: ScannedFile): CachedHashes? {
        val e = dao.get(file.key) ?: return null
        if (e.sizeBytes != file.sizeBytes || e.dateModified != file.dateModifiedMillis) return null
        return CachedHashes(e.sha256, e.pHash, e.dHash, e.width, e.height)
    }

    override fun store(file: ScannedFile, hashes: CachedHashes) {
        val old = dao.get(file.key)?.takeIf { it.sizeBytes == file.sizeBytes && it.dateModified == file.dateModifiedMillis }
        dao.put(
            HashCacheEntity(
                key = file.key,
                sizeBytes = file.sizeBytes,
                dateModified = file.dateModifiedMillis,
                sha256 = hashes.sha256 ?: old?.sha256,
                pHash = hashes.pHash ?: old?.pHash,
                dHash = hashes.dHash ?: old?.dHash,
                width = hashes.width ?: old?.width,
                height = hashes.height ?: old?.height
            )
        )
    }
}
