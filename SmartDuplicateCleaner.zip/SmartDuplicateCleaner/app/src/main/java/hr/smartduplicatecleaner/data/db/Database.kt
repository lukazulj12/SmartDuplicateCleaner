package hr.smartduplicatecleaner.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/** Metapodaci datoteke koja je član neke grupe duplikata. */
@Entity(tableName = "files")
data class FileEntity(
    @PrimaryKey val key: String,
    val uri: String,
    val source: String,
    val name: String,
    val volume: String?,
    val relativeDir: String,
    val sizeBytes: Long,
    val mimeType: String?,
    val category: String,
    val dateTaken: Long?,
    val dateTakenSource: String?,
    val dateAdded: Long?,
    val dateModified: Long?,
    val width: Int?,
    val height: Int?,
    val treeUri: String?,
    val documentId: String?,
    val absolutePath: String?,
    val sha256: String?,
    val pHash: Long?,
    val dHash: Long?
)

@Entity(tableName = "dup_groups")
data class GroupEntity(
    @PrimaryKey val id: String,
    val type: String,
    val category: String,
    val maxDistance: Int?,
    val needsManual: Boolean,
    /** Kodirani razlozi na razini grupe (vidi Reason.encodeList). */
    val notes: String,
    val position: Int
)

@Entity(tableName = "members", primaryKeys = ["groupId", "fileKey"])
data class MemberEntity(
    val groupId: String,
    val fileKey: String,
    val contentLabel: Int,
    val suggestion: String,
    val reasons: String
)

/** Datoteka koju je korisnik (ili automatski prijedlog) označio za brisanje. */
@Entity(tableName = "marks")
data class MarkEntity(@PrimaryKey val fileKey: String)

/** Sažetak posljednjeg skeniranja (jedan red, id = 0). */
@Entity(tableName = "summary")
data class SummaryEntity(
    @PrimaryKey val id: Int = 0,
    val finishedAt: Long,
    val filesListed: Int,
    val filesAnalyzed: Int,
    val analyzedBytes: Long,
    val skippedBySize: Int,
    val skippedBySizeBytes: Long,
    val skippedPotentialDuplicates: Int,
    val skippedByCategory: Int,
    val skippedByFolder: Int,
    val unreadableFiles: Int,
    val undecodableImages: Int,
    val duplicateFiles: Int,
    val reclaimableBytes: Long,
    val groupCount: Int,
    /** Upozorenja: "izvor|vrsta|detalj" odvojena novim retkom. */
    val warnings: String,
    val maxFileSizeBytes: Long?
)

/** Predmemorija hashova – vrijedi dok se veličina i datum izmjene ne promijene. */
@Entity(tableName = "hash_cache")
data class HashCacheEntity(
    @PrimaryKey val key: String,
    val sizeBytes: Long,
    val dateModified: Long?,
    val sha256: String?,
    val pHash: Long?,
    val dHash: Long?,
    val width: Int?,
    val height: Int?
)

/** Zapis o datoteci koja je premještena u koš / mapu za oporavak. */
@Entity(tableName = "recovery")
data class RecoveryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val displayPath: String,
    val sizeBytes: Long,
    val mimeType: String?,
    val deletedAt: Long,
    /** MEDIA_TRASH, SAF_COPY ili FILE_MOVE */
    val method: String,
    val mediaUri: String?,
    val recoveredPath: String?,
    val treeUri: String?,
    val parentDocumentId: String?,
    val originalAbsolutePath: String?
)

/** Abstraktna klasa (ne sučelje) kako bi Room ispravno generirao transakcijske metode s tijelom. */
@Dao
abstract class ResultsDao {
    @Query("SELECT * FROM files") abstract suspend fun files(): List<FileEntity>
    @Query("SELECT * FROM dup_groups ORDER BY position") abstract suspend fun groups(): List<GroupEntity>
    @Query("SELECT * FROM members") abstract suspend fun members(): List<MemberEntity>
    @Query("SELECT fileKey FROM marks") abstract suspend fun marks(): List<String>
    @Query("SELECT * FROM summary WHERE id = 0") abstract fun summaryFlow(): Flow<SummaryEntity?>
    @Query("SELECT * FROM summary WHERE id = 0") abstract suspend fun summary(): SummaryEntity?
    @Query("SELECT COUNT(*) FROM marks") abstract fun markCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertFiles(list: List<FileEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertGroups(list: List<GroupEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertMembers(list: List<MemberEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertMarks(list: List<MarkEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertSummary(s: SummaryEntity)

    @Query("DELETE FROM files") abstract suspend fun clearFiles()
    @Query("DELETE FROM dup_groups") abstract suspend fun clearGroups()
    @Query("DELETE FROM members") abstract suspend fun clearMembers()
    @Query("DELETE FROM marks") abstract suspend fun clearMarks()

    @Query("DELETE FROM marks WHERE fileKey IN (:keys)") abstract suspend fun deleteMarks(keys: List<String>)
    @Query("DELETE FROM members WHERE fileKey IN (:keys)") abstract suspend fun deleteMembers(keys: List<String>)
    @Query("DELETE FROM files WHERE `key` IN (:keys)") abstract suspend fun deleteFiles(keys: List<String>)
    @Query("DELETE FROM dup_groups WHERE id IN (:ids)") abstract suspend fun deleteGroups(ids: List<String>)
    @Query("DELETE FROM members WHERE groupId IN (:ids)") abstract suspend fun deleteMembersOfGroups(ids: List<String>)

    @Transaction
    open suspend fun replaceAll(
        files: List<FileEntity>, groups: List<GroupEntity>, members: List<MemberEntity>,
        marks: List<MarkEntity>, summary: SummaryEntity
    ) {
        clearMarks(); clearMembers(); clearGroups(); clearFiles()
        files.chunked(500).forEach { insertFiles(it) }
        groups.chunked(500).forEach { insertGroups(it) }
        members.chunked(500).forEach { insertMembers(it) }
        marks.chunked(500).forEach { insertMarks(it) }
        insertSummary(summary)
    }

    @Transaction
    open suspend fun replaceMarks(keys: Collection<String>) {
        clearMarks()
        keys.map { MarkEntity(it) }.chunked(500).forEach { insertMarks(it) }
    }
}

@Dao
interface HashCacheDao {
    @Query("SELECT * FROM hash_cache WHERE `key` = :key") fun get(key: String): HashCacheEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun put(entity: HashCacheEntity)
    @Query("DELETE FROM hash_cache") suspend fun clear()
}

@Dao
interface RecoveryDao {
    @Query("SELECT * FROM recovery ORDER BY deletedAt DESC") fun all(): Flow<List<RecoveryEntity>>
    @Query("SELECT * FROM recovery") suspend fun list(): List<RecoveryEntity>
    @Insert suspend fun insert(e: RecoveryEntity): Long
    @Query("DELETE FROM recovery WHERE id IN (:ids)") suspend fun delete(ids: List<Long>)
}

@Database(
    entities = [
        FileEntity::class, GroupEntity::class, MemberEntity::class, MarkEntity::class,
        SummaryEntity::class, HashCacheEntity::class, RecoveryEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun results(): ResultsDao
    abstract fun hashCache(): HashCacheDao
    abstract fun recovery(): RecoveryDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "sdc.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
