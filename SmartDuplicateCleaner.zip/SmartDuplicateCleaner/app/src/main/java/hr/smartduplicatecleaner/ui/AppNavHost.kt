package hr.smartduplicatecleaner.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.delete.DeletionReportScreen
import hr.smartduplicatecleaner.ui.delete.DeletionReviewScreen
import hr.smartduplicatecleaner.ui.home.HomeScreen
import hr.smartduplicatecleaner.ui.recovery.RecoveryScreen
import hr.smartduplicatecleaner.ui.recovery.RecoveryViewModel
import hr.smartduplicatecleaner.ui.results.CompareScreen
import hr.smartduplicatecleaner.ui.results.GroupDetailScreen
import hr.smartduplicatecleaner.ui.results.ResultsScreen
import hr.smartduplicatecleaner.ui.results.ReviewViewModel
import hr.smartduplicatecleaner.ui.settings.FoldersScreen
import hr.smartduplicatecleaner.ui.settings.SettingsScreen

/** Navigacija između zaslona. */
@Composable
fun AppNavHost(container: AppContainer) {
    val nav = rememberNavController()
    // Jedan ViewModel za pregled i brisanje, vezan uz aktivnost (dijele ga svi zasloni pregleda).
    val review: ReviewViewModel = viewModel(factory = viewModelFactory { initializer { ReviewViewModel(container) } })
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    val summary by container.results.summary.collectAsState(initial = null)
    val prefs = DisplayPrefs(settings.sizeUnit, settings.europeanDates)
    LaunchedEffect(summary?.finishedAt) { review.ensureFresh(summary?.finishedAt) }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                container = container,
                onReview = { nav.navigate("results") },
                onSettings = { nav.navigate("settings") },
                onFolders = { nav.navigate("folders") },
                onRecovery = { nav.navigate("recovery") }
            )
        }
        composable("results") {
            ResultsScreen(
                vm = review,
                prefs = prefs,
                onBack = { nav.popBackStack() },
                onOpenGroup = { id -> nav.navigate("group/$id") },
                onReviewDeletion = { nav.navigate("deleteReview") }
            )
        }
        composable("group/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            val id = entry.arguments?.getString("id").orEmpty()
            GroupDetailScreen(
                vm = review,
                groupId = id,
                prefs = prefs,
                onBack = { nav.popBackStack() },
                // Prethodna/sljedeća grupa zamjenjuje trenutačnu, pa "natrag" vodi na popis.
                onOpenGroup = { next -> nav.navigate("group/$next") { popUpTo("results") } },
                onCompare = { gid, index -> nav.navigate("compare/$gid/$index") }
            )
        }
        composable(
            "compare/{id}/{index}",
            arguments = listOf(
                navArgument("id") { type = NavType.StringType },
                navArgument("index") { type = NavType.IntType }
            )
        ) { entry ->
            CompareScreen(
                vm = review,
                groupId = entry.arguments?.getString("id").orEmpty(),
                startIndex = entry.arguments?.getInt("index") ?: 0,
                prefs = prefs,
                onBack = { nav.popBackStack() }
            )
        }
        composable("deleteReview") {
            DeletionReviewScreen(
                vm = review,
                prefs = prefs,
                mode = settings.deletionMode,
                onBack = { nav.popBackStack() },
                onFinished = { nav.navigate("deleteReport") { popUpTo("results") } }
            )
        }
        composable("deleteReport") {
            DeletionReportScreen(vm = review, prefs = prefs, onDone = { nav.popBackStack("results", inclusive = false) })
        }
        composable("settings") {
            SettingsScreen(repo = container.settings, onBack = { nav.popBackStack() }, onFolders = { nav.navigate("folders") })
        }
        composable("folders") {
            FoldersScreen(repo = container.settings, onBack = { nav.popBackStack() })
        }
        composable("recovery") {
            val vm: RecoveryViewModel = viewModel(factory = viewModelFactory { initializer { RecoveryViewModel(container) } })
            RecoveryScreen(vm = vm, prefs = prefs, onBack = { nav.popBackStack() })
        }
    }
}
