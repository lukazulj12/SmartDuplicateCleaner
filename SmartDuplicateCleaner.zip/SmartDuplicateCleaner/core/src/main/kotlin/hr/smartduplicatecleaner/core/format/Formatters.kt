package hr.smartduplicatecleaner.core.format

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

/** Jedinica za prikaz veličine. AUTO bira najprikladniju. */
enum class SizeUnit { AUTO, B, KB, MB, GB }

object Formatters {
    /** Decimalne jedinice (1 MB = 1 000 000 B), kao u Androidovim postavkama pohrane. */
    private const val K = 1000.0

    fun size(bytes: Long, unit: SizeUnit, locale: Locale): String {
        val symbols = DecimalFormatSymbols.getInstance(locale)
        val oneDecimal = DecimalFormat("#,##0.0", symbols)
        val twoDecimals = DecimalFormat("#,##0.00", symbols)
        val integer = DecimalFormat("#,##0", symbols)
        val resolved = if (unit != SizeUnit.AUTO) unit else when {
            bytes < K -> SizeUnit.B
            bytes < K * K -> SizeUnit.KB
            bytes < K * K * K -> SizeUnit.MB
            else -> SizeUnit.GB
        }
        return when (resolved) {
            SizeUnit.B, SizeUnit.AUTO -> integer.format(bytes) + " B"
            SizeUnit.KB -> oneDecimal.format(bytes / K) + " KB"
            SizeUnit.MB -> oneDecimal.format(bytes / (K * K)) + " MB"
            SizeUnit.GB -> twoDecimals.format(bytes / (K * K * K)) + " GB"
        }
    }

    private val EURO_DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")
    private val EURO_DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy")

    /** Datum i vrijeme; [european] = format DD.MM.GGGG, inače lokalni format jezika. */
    fun dateTime(millis: Long, european: Boolean, locale: Locale, zone: ZoneId = ZoneId.systemDefault()): String {
        val formatter = if (european) EURO_DATE_TIME
        else DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT).withLocale(locale)
        return formatter.format(Instant.ofEpochMilli(millis).atZone(zone))
    }

    fun date(millis: Long, european: Boolean, locale: Locale, zone: ZoneId = ZoneId.systemDefault()): String {
        val formatter = if (european) EURO_DATE else DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(locale)
        return formatter.format(Instant.ofEpochMilli(millis).atZone(zone))
    }

    /** Parsiranje ručnog unosa veličine u MB ("12,5" ili "12.5"); null za neispravan unos. */
    fun parseMegabytes(text: String): Long? {
        val value = text.trim().replace(',', '.').toDoubleOrNull() ?: return null
        if (value <= 0 || value > 1_000_000) return null
        return (value * 1_000_000).toLong()
    }
}
