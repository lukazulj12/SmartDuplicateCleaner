package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.model.DateKind
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.ScannedFile
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

/** Parsiranje EXIF datuma uz provjeru pouzdanosti. */
object ExifDateParser {
    private val FORMAT = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss")
    /** Datumi prije 1. 1. 1990. smatraju se neispravnima (tvornički postavljen sat i sl.). */
    private val MIN_RELIABLE: Long = LocalDateTime.of(1990, 1, 1, 0, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

    /**
     * @param value  npr. "2023:01:15 10:20:30"
     * @param offset npr. "+01:00" (EXIF OffsetTimeOriginal), ako postoji
     * @param zone   vremenska zona uređaja koja se koristi ako pomak nije zapisan
     * @param nowMillis trenutačno vrijeme – datumi u budućnosti smatraju se nepouzdanima
     * @return milisekunde ili null ako datum nije pouzdan
     */
    fun parse(value: String?, offset: String?, zone: ZoneId, nowMillis: Long): Long? {
        val trimmed = value?.trim()?.takeIf { it.length >= 19 } ?: return null
        if (trimmed.startsWith("0000")) return null
        val local = try {
            LocalDateTime.parse(trimmed.substring(0, 19), FORMAT)
        } catch (e: DateTimeParseException) {
            return null
        }
        val millis = try {
            if (!offset.isNullOrBlank()) local.toInstant(ZoneOffset.of(offset.trim())).toEpochMilli()
            else local.atZone(zone).toInstant().toEpochMilli()
        } catch (e: Exception) {
            local.atZone(zone).toInstant().toEpochMilli()
        }
        if (millis < MIN_RELIABLE) return null
        if (millis > nowMillis + 24L * 3600 * 1000) return null
        return millis
    }
}

/** Datum koji se stvarno koristi za usporedbu, s izvorom i oznakom je li zamjenski. */
data class ResolvedDate(val millis: Long, val source: DateSource, val isFallback: Boolean)

object DateResolver {
    /**
     * Vraća datum prema odabranoj vrsti. Datum dodavanja (kopiranja) nikad se ne predstavlja
     * kao datum snimanja – ako se koristi kao zamjena, označen je s [ResolvedDate.isFallback].
     */
    fun resolve(file: ScannedFile, kind: DateKind): ResolvedDate? = when (kind) {
        DateKind.CAPTURE_ONLY -> captured(file)
        DateKind.CAPTURE_WITH_FALLBACK -> captured(file) ?: fallback(file)
        DateKind.DATE_ADDED -> file.dateAddedMillis?.let { ResolvedDate(it, DateSource.DATE_ADDED, false) }
        DateKind.LAST_MODIFIED -> file.dateModifiedMillis?.let { ResolvedDate(it, DateSource.LAST_MODIFIED, false) }
    }

    private fun captured(file: ScannedFile): ResolvedDate? {
        val millis = file.dateTakenMillis ?: return null
        return ResolvedDate(millis, file.dateTakenSource ?: DateSource.MEDIA_METADATA, false)
    }

    /**
     * Zamjena: najraniji poznati datum datoteke. Datum kopiranja je uvijek jednak ili kasniji
     * od stvarnog nastanka, pa je najraniji datum najbliži istini.
     */
    private fun fallback(file: ScannedFile): ResolvedDate? {
        val modified = file.dateModifiedMillis?.takeIf { it > 0 }
        val added = file.dateAddedMillis?.takeIf { it > 0 }
        return when {
            modified != null && (added == null || modified <= added) ->
                ResolvedDate(modified, DateSource.LAST_MODIFIED, true)
            added != null -> ResolvedDate(added, DateSource.DATE_ADDED, true)
            else -> null
        }
    }
}
