package hr.smartduplicatecleaner.core.model

/** Koji se datum koristi za pravilo "starija / novija datoteka". */
enum class DateKind {
    /** Datum snimanja (EXIF/metapodaci); ako ga nema, zamjenski najraniji poznati datum datoteke – jasno označen. */
    CAPTURE_WITH_FALLBACK,
    /** Samo datum snimanja; ako nedostaje ijednoj datoteci, kriterij se preskače. */
    CAPTURE_ONLY,
    /** Datum dodavanja na uređaj (približno datum kopiranja). */
    DATE_ADDED,
    /** Datum posljednje izmjene. */
    LAST_MODIFIED
}

enum class DatePreference { OLDER, NEWER, NONE }
enum class SizePreference { LARGER, SMALLER, NONE }

/** Kriteriji za odabir datoteke koju zadržavamo, poredani po prioritetu. */
enum class CriterionType { DATE, SIZE, RESOLUTION, CAMERA_FOLDER }

data class KeepRules(
    val order: List<CriterionType> = DEFAULT_ORDER,
    val datePreference: DatePreference = DatePreference.OLDER,
    val dateKind: DateKind = DateKind.CAPTURE_WITH_FALLBACK,
    val sizePreference: SizePreference = SizePreference.LARGER,
    val preferHigherResolution: Boolean = true,
    val preferCameraFolder: Boolean = false
) {
    fun isEnabled(type: CriterionType): Boolean = when (type) {
        CriterionType.DATE -> datePreference != DatePreference.NONE
        CriterionType.SIZE -> sizePreference != SizePreference.NONE
        CriterionType.RESOLUTION -> preferHigherResolution
        CriterionType.CAMERA_FOLDER -> preferCameraFolder
    }

    /** Redoslijed koji uvijek sadrži sve kriterije točno jednom (zaštita od oštećenih postavki). */
    fun normalizedOrder(): List<CriterionType> {
        val seen = LinkedHashSet<CriterionType>()
        order.forEach { seen.add(it) }
        CriterionType.entries.forEach { seen.add(it) }
        return seen.toList()
    }

    companion object {
        val DEFAULT_ORDER = listOf(CriterionType.DATE, CriterionType.SIZE, CriterionType.RESOLUTION, CriterionType.CAMERA_FOLDER)
    }
}

/** Postavke koje utječu na skeniranje i grupiranje. */
data class ScanSettings(
    /** Najveća veličina datoteke u bajtovima; null = bez ograničenja. */
    val maxFileSizeBytes: Long? = 100L * MB,
    val categories: Set<FileCategory> = FileCategory.entries.toSet(),
    /** Traže li se i "slične" fotografije (zahtijevaju ručnu provjeru). */
    val findSimilarPhotos: Boolean = true,
    /** Prag sličnosti u postocima (75–98). Viši prag = strože. */
    val similarityPercent: Int = 85,
    /** Ograničenje paralelnih poslova (štedi bateriju i memoriju). */
    val parallelism: Int = 2,
    /** Ograničenje skeniranja na odabrane relativne mape (prazno = cijela dostupna pohrana). */
    val includedRelativeDirs: Set<String> = emptySet()
) {
    /** Najveća Hammingova udaljenost (od 64 bita) za "slične" fotografije. */
    val similarMaxDistance: Int
        get() = ((100 - similarityPercent.coerceIn(50, 99)) * 64 / 100).coerceAtLeast(VISUAL_MAX_DISTANCE + 1)

    companion object {
        const val MB = 1_000_000L
        /** Stroga granica za "vizualni duplikat" (≈ 90,6 % podudarnosti pHasha). */
        const val VISUAL_MAX_DISTANCE = 6
        /** Dodatna potvrda dHashom za vizualni duplikat. */
        const val VISUAL_MAX_DHASH_DISTANCE = 10
        /** Dopuštena razlika omjera stranica za vizualni duplikat (3 %). */
        const val VISUAL_ASPECT_TOLERANCE = 0.03
    }
}
